import { Component,EventEmitter,Input, Output } from '@angular/core';
import { DUMMY_USERS } from '../dummy-users';
import { ImageModule } from 'primeng/image';
import { ButtonModule } from 'primeng/button';
import { User } from './user.model';
import { CardComponent } from "../shared/card/card.component";
// const randonIndex=Math.floor(Math.random()*DUMMY_USERS.length);

@Component({
  selector: 'app-user',
  // imports: [ImageModule, ButtonModule, CardComponent],
  templateUrl: './user.component.html',
  styleUrl: './user.component.scss'
})
export class UserComponent {
// selectedUsers=DUMMY_USERS[randonIndex];
// @Input ({required:true}) id!:string;
// @Input ({required:true}) avatar!:string;
// @Input ({required:true}) name!:string;
@Input ({required:true}) user!:User;
@Input ({required:true}) selected!:boolean;
@Output() select=new EventEmitter<string>();
get getPath(){
  return 'assets/users/'+ this.user.avatar;
}

onselectUser(){
 this.select.emit(this.user.id);
}
}
