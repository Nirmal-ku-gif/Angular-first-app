import { NgModule } from "@angular/core";
import { SharedModule } from "primeng/api";

import { AppComponent } from "./app.component";
import { UserComponent } from "./user/user.component";
import { BrowserModule } from "@angular/platform-browser";
import { CardComponent } from "./shared/card/card.component";




 @NgModule({
     declarations: [AppComponent,
        UserComponent,
        CardComponent
    ],
     bootstrap: [AppComponent],
     imports: [BrowserModule,SharedModule],
 })

export class AppModule{

}