import { Component, Input } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { type newTaskData } from './task/task.model';
import { TasksServices } from './tasks.service';
@Component({
  selector: 'app-tasks',
  // imports: [ButtonModule,
  //   TaskComponent,
  //   NewTaskComponent
  // ],
  templateUrl: './tasks.component.html',
  styleUrl: './tasks.component.scss'
})
export class TasksComponent {
  isAddingTask=false;
  @Input ({required:true}) userid!:string;
  @Input ({required:true}) name!:string;

  constructor (private tasksService:TasksServices){

  }
get selectedUserTasks(){
  return this.tasksService.getUserTasks(this.userid);
}

onStartAddTask(){
  this.isAddingTask=true;
}
onCloseAddTask(){
  this.isAddingTask=false;
}

}
