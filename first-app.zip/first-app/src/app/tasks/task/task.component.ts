import { Component,inject,Input, Output } from '@angular/core';
import { CardModule } from 'primeng/card';
import { Task } from './task.model';
import { TasksServices } from '../tasks.service';

@Component({
  selector: 'app-task',
  // imports: [CardModule, CardComponent,DatePipe],
  templateUrl: './task.component.html',
  styleUrl: './task.component.scss'
})
export class TaskComponent {
@Input ({required:true}) task!:Task;
taskService=inject(TasksServices)

onCompleteTask(){
this.taskService.removeTasks(this.task.id);
}
}
