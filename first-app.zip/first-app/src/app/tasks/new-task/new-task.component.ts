import { Component, EventEmitter, inject, Input, Output } from '@angular/core';
import {type  newTaskData } from '../task/task.model';
import { TasksServices } from '../tasks.service';
@Component({
  selector: 'app-new-task',

  // imports: [FormsModule,ButtonModule],
  templateUrl: './new-task.component.html',
  styleUrl: './new-task.component.scss'
})
export class NewTaskComponent {
  enteredTitle='';
  enteredSummary='';
  enteredDate='';
  private tasksService=inject(TasksServices)

@Input({required:true}) userId!:string;
  @Output() close=new EventEmitter<void>();
  @Output() add=new EventEmitter<newTaskData>();
  onCancel(){
      this.close.emit();
  }
  onSubmit(){
    console.log('here');
   this.tasksService.addTasks({
    title:this.enteredTitle,
    summary:this.enteredSummary,
    dueDate:this.enteredDate
   },
  this.userId);
  this.close.emit();
  }
}
