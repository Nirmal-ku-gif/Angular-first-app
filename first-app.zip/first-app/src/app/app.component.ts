import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { UserComponent } from "./user/user.component";
import { ImageModule } from 'primeng/image';
import { DUMMY_USERS } from './dummy-users';
import { TasksComponent } from "./tasks/tasks.component";

import { ButtonModule } from 'primeng/button';
@Component({
  selector: 'app-root',
//   imports: [
//     RouterOutlet,
//     UserComponent,
//     ImageModule,
//     TasksComponent,
//     ButtonModule,
// ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = 'first-app';
  onSelectUserId ?: string;
  users=DUMMY_USERS;

  get selectedUser(){
    return this.users.find((user)=>user.id===this.onSelectUserId)
  }
  onSelectUser(id:string){
    this.onSelectUserId=id;
  }
}
